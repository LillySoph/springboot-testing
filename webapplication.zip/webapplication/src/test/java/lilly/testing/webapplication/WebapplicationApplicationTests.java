package lilly.testing.webapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
